---
name: Porsche Cayenne
brand: Porsche
price: '66,800'
year: '2020'
description: >-
  Battery:

  800-volt performance battery


  Range:

  192 miles (Standard)


  Plug-in-Charging:

  Porsche turbocharging 270kw at 800-volt chargers. Mobile charger 240v NEMA
  14-50 outlet


  Length:

  195 in.


  Width:

  77-78 in.


  Height:

  54 in.
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/cayenne-white.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/cayenne-silver.png
  - name: Gray
    color: '#303030'
    image: /uploads/cayenne-gray.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/cayenne-black.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/cayenne-red.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/cayenne-blue.png
permalink:
---
