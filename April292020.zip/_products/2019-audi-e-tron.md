---
name: Audi e-tron
brand: Audi
price: '74,800'
description_markdown: >-
  The Audi e-tron is an electric SUV.


  <u><strong>Battery:</strong></u>


  95 kWh 396 V lithium-ion


  **<u>Transmission:</u>**


  Single speed with fixed ratio


  **<u>Battery: </u>**


  55 quattro: 95 kWh lithium ion (83.6 kWh usable)/50 quattro: 71 kWh lithium
  ion (64.7 kWh usable)


  **<u>Range:</u>**


  * 55 quattro: 204 mi (328 km)

  * 50 quattro: 150 mi (241 km)

  * 55 quattro: 222 to 259 mi (357 to 417 km)

  * 50 quattro: 186 mi (299 km)


  **<u>Plug-in charging:</u>**


  11 kW AC22 kW AC (optional)150 kW (also compatible with 50-300 kW charging
  stations)


  &nbsp;


  <u><strong>Wheelbase:</strong></u>


  2,928 mm (115.3 in)


  <u><strong>Length:</strong></u>


  4,901 mm (193.0 in)


  <u><strong>Width:</strong></u>


  1,935 mm (76.2 in)


  <u><strong>Height:</strong></u>


  1,616 mm (63.6 in)
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/e-tron-white.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/e-tron-silver.png
  - name: Gray
    color: '#303030'
    image: /uploads/e-tron-gray.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/e-tron-black.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/e-tron-red.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/e-tron-blue.png
year: 2019
permalink: /cars/audi/e-tron
---

The 2020 Tesla Cybertruck is Tesla's new futuristic car aimed at having "Better utility than a truck with more performance than a sports car."
Specs: 
0-60 MPH in 6.5 SECONDS.
Range: 250+ Miles (EPA EST.)
Drivetrarin Rear-Wheel Drive.
Storage: 100 CU FT.
Vault Length: 6.5 FT.
Towing Capacity: 7,500+ LBS.
Autopilot Standard.
Adaptive Air Suspension Standard.



