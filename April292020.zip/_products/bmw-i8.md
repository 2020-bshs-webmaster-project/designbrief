---
name: BMW i8
brand: BMW
price: '147,500'
description_markdown:
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/i8-white.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/i8-silver.png
  - name: Gray
    color: '#303030'
    image: /uploads/i8-gray.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/i8-black.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/i8-red.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/i8-blue.png
year: 2020
permalink: /cars/bmw/i8
---

The 2020 Tesla Cybertruck is Tesla's new futuristic car aimed at having "Better utility than a truck with more performance than a sports car."
Specs: 
0-60 MPH in 6.5 SECONDS.
Range: 250+ Miles (EPA EST.)
Drivetrarin Rear-Wheel Drive.
Storage: 100 CU FT.
Vault Length: 6.5 FT.
Towing Capacity: 7,500+ LBS.
Autopilot Standard.
Adaptive Air Suspension Standard.



