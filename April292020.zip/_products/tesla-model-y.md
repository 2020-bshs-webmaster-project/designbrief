---
name: Tesla Model Y
brand: Tesla
price: '48,000'
description_markdown: >-
  The Tesla Model Y is an upcoming electric compact crossover utility vehicle.
  It is expected to be released in Summer 2020.


  <u><strong>Transmission:</strong></u>


  1-speed direct drive


  <br><u><strong>Electric Range:</strong></u>


  300 or 230 or 280 miles (483 or 370 or 451 km)


  <br>**Please note that this vehicle is still in development, so not all
  information about the vehicle is available at this time.**
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/modely-white.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/modely-silver.png
  - name: Gray
    color: '#303030'
    image: /uploads/modely-gray.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/modely-black.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/modely-red.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/modely-blue.png
year: 2020
permalink: /cars/tesla/model-y
---
