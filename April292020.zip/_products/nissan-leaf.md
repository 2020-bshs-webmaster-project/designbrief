---
name: Nissan LEAF
brand: Nissan
price: '31,600'
description_markdown: >-
  The Nissan LEAF is an electric SUV.


  <u><strong>Battery:</strong></u>


  40-62 kWh lithium-ion


  <u><strong>Transmission:</strong></u>


  1-speed automatic


  <u><strong>Range:</strong></u>


  * 243 km (151 miles)

  * 270 km (170 miles)


  <u><strong>Plug-in charging:</strong></u>


  11 kW AC22 kW AC (optional)150 kW (also compatible with 50-300 kW charging
  stations)


  &nbsp;


  <u><strong>Wheelbase:</strong></u>


  2,700 mm (106.3 in)


  <u><strong>Length:</strong></u>


  4,490 mm (176.8 in)


  <u><strong>Width:</strong></u>


  1,788 mm (70.4 in)


  <u><strong>Height:</strong></u>


  1,530 mm (60.2 in)
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/white.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/silver.png
  - name: Gray
    color: '#303030'
    image: /uploads/gray.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/black.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/red.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/blue.png
year: 2020
permalink: /cars/nissan/leaf
---
