---
name: Brady Kondek
image_path: 'https://unsplash.it/600/800?image=1062'
---