---
name: Jaguar I-Pace
brand: Jaguar
price: '69,000'
description_markdown: >-
  The Jaguar I Pace is an electric SUV.


  <u><strong>Battery:</strong></u>


  90 kWh lithium-ion


  **<u>Electric motor:</u>**


  2 x 200 PS (150 kW) 348 N⋅m (257 lbf⋅ft) (total 400 PS (290 kW) 696 N⋅m (513
  lbf⋅ft))


  **<u>Electric range:</u>**


  234 miles (377 km) and 292 miles (470 km)


  **<u>Plug-in charging:</u>**


  7 kW AC/100 kW DC


  &nbsp;


  <u><strong>Wheelbase:</strong></u>


  2,990 mm (117.7 in)


  <u><strong>Length:</strong></u>


  4,682 mm (184.3 in)


  <u><strong>Width:</strong></u>


  * 1,895 mm (74.6 in) (body)

  * 2,011 mm (79.2 in) (mirrors folded)

  * 2,139 mm (84.2 in) (mirrors unfolded)


  <u><strong>Height:</strong></u>


  1,565 mm (61.6 in)
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/i-pace-white.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/i-pace-silver.png
  - name: Gray
    color: '#303030'
    image: /uploads/i-pace-gray.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/i-pace-black.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/i-pace-red.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/i-pace-blue.png
year: 2019
permalink: /cars/jaguar/i-pace
---

The 2020 Tesla Cybertruck is Tesla's new futuristic car aimed at having "Better utility than a truck with more performance than a sports car."
Specs: 
0-60 MPH in 6.5 SECONDS.
Range: 250+ Miles (EPA EST.)
Drivetrarin Rear-Wheel Drive.
Storage: 100 CU FT.
Vault Length: 6.5 FT.
Towing Capacity: 7,500+ LBS.
Autopilot Standard.
Adaptive Air Suspension Standard.



