---
name: Tesla Cybertruck
brand: Tesla
price: '39,900'
description_markdown: >-
  The Tesla Cybertruck is an all-electric battery-powered light commercial
  vehicle.


  <br>**Please note that this vehicle is still in development.**
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/cybertruck-white-1.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/cybertruck-silver-1.png
  - name: Gray
    color: '#303030'
    image: /uploads/cybertruck-gray-1.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/cybertruck-black-1.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/cybertruck-red-1.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/cybertruck-blue-1.png
year: 2020
permalink: /cars/tesla/cybertruck
---

The 2020 Tesla Cybertruck is Tesla's new futuristic car aimed at having "Better utility than a truck with more performance than a sports car."
Specs: 
0-60 MPH in 6.5 SECONDS.
Range: 250+ Miles (EPA EST.)
Drivetrarin Rear-Wheel Drive.
Storage: 100 CU FT.
Vault Length: 6.5 FT.
Towing Capacity: 7,500+ LBS.
Autopilot Standard.
Adaptive Air Suspension Standard.



