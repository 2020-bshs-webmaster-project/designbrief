---
name: Porsche Taycan
brand: Porsche
price: '103,800'
year: '2020'
description: >-
  Battery:

  800-volt performance battery


  Range:

  192 miles (Standard)


  Plug-in-Charging:

  Porsche turbocharging 270kw at 800-volt chargers. Mobile charger 240v NEMA
  14-50 outlet


  Length:

  195 in.


  Width:

  77-78 in.


  Height:

  54 in.
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/white-1.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/silver-1.png
  - name: Gray
    color: '#303030'
    image: /uploads/gray-1.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/black-1.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/red-1.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/blue-1.png
permalink:
---
