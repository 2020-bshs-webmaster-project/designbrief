---
name: Kia Soul EV
brand: Kia
price: '17,490'
description_markdown:
type:
  - Car/Sedan
styles:
  - name: White
    color: '#ffffff'
    image: /uploads/soul-white.png
  - name: Silver
    color: '#a0a0a0'
    image: /uploads/soul-silver.png
  - name: Gray
    color: '#303030'
    image: /uploads/soul-gray.png
  - name: Black
    color: '#0c0c0c'
    image: /uploads/soul-black.png
  - name: Red
    color: '#ff1c1c'
    image: /uploads/soul-red.png
  - name: Blue
    color: '#0026ff'
    image: /uploads/soul-blue.png
year: 2020
permalink: 'https://www.kia.com/us/en/soul'
---

The 2020 Tesla Cybertruck is Tesla's new futuristic car aimed at having "Better utility than a truck with more performance than a sports car."
Specs: 
0-60 MPH in 6.5 SECONDS.
Range: 250+ Miles (EPA EST.)
Drivetrarin Rear-Wheel Drive.
Storage: 100 CU FT.
Vault Length: 6.5 FT.
Towing Capacity: 7,500+ LBS.
Autopilot Standard.
Adaptive Air Suspension Standard.



